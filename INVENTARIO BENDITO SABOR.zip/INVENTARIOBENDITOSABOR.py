# ============================================================
# FUNDAMENTOS DE PROGRAMACIÓN - FASE 5
# Problema 3: Auditoría de Inventario
# Restaurante: Bendito Sabor
# ============================================================

# ---- MÓDULO (FUNCIÓN) ----
def calcular_pedido(stock_actual, stock_minimo):
    """
    Determina la cantidad exacta a pedir para un ingrediente.
    Si el stock actual es menor al mínimo, retorna la diferencia.
    Si el stock es suficiente, retorna 0.
    """
    if stock_actual < stock_minimo:
        cantidad = stock_minimo - stock_actual
    else:
        cantidad = 0
    return cantidad


# ---- MATRIZ DE INVENTARIO ----
# Estructura: [Código, Nombre, Stock Actual, Stock Mínimo, Unidad]
# Stock Actual inicia en 0, luego el usuario lo ingresa

inventario = [
    ["B001", "Pan de hamburguesa",   0,  50, "und"],
    ["B002", "Carne 125g",           0,  30, "und"],
    ["B003", "Carne 150g",           0,  25, "und"],
    ["B004", "Tomate",               0,  20, "und"],
    ["B005", "Queso",                0,  15, "und"],
    ["B006", "Papa criolla",         0,  10, "kg" ],
    ["B007", "Platano verde",        0,  20, "und"],
    ["B008", "Carne desmechada",     0,   8, "kg" ],
    ["B009", "Pollo desmechado",     0,   8, "kg" ],
    ["B010", "Salchicha americana",  0,  30, "und"],
]


# ---- INGRESO DE STOCK ACTUAL ----
print("=" * 60)
print("       RESTAURANTE BENDITO SABOR")
print("       INGRESO DE STOCK ACTUAL")
print("=" * 60)
print("Por favor ingrese el stock actual de cada ingrediente:")
print("-" * 60)

for articulo in inventario:
    while True:
        try:
            cantidad = int(input(f"  Stock actual de {articulo[1]} ({articulo[4]}): "))
            if cantidad < 0:
                print("  ⚠ El valor no puede ser negativo. Intente de nuevo.")
            else:
                articulo[2] = cantidad
                break
        except ValueError:
            print("  ⚠ Ingrese solo números enteros. Intente de nuevo.")


# ---- LÓGICA PRINCIPAL ----
print()
print("=" * 60)
print("       RESTAURANTE BENDITO SABOR")
print("       AUDITORÍA DE INVENTARIO - LISTA DE PEDIDOS")
print("=" * 60)
print(f"{'Código':<8} {'Ingrediente':<25} {'Pedir':>8} {'Unidad':>6}")
print("-" * 60)

hay_pedidos = False

for articulo in inventario:
    codigo       = articulo[0]
    nombre       = articulo[1]
    stock_actual = articulo[2]
    stock_minimo = articulo[3]
    unidad       = articulo[4]

    cantidad_pedido = calcular_pedido(stock_actual, stock_minimo)

    if cantidad_pedido > 0:
        print(f"{codigo:<8} {nombre:<25} {cantidad_pedido:>8} {unidad:>6}")
        hay_pedidos = True

print("-" * 60)

if hay_pedidos:
    print("  ⚠ Los anteriores ingredientes deben reabastecerse.")
else:
    print("  ✓ Todos los ingredientes tienen stock suficiente.")

print("=" * 60)